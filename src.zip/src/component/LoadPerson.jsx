import React ,{useRef,useState} from 'react'

const  LoadPerson = (props, ref) => {
   

    // the trigger comes from parent button component 
    // make a call and loads the person ... 
    // message to the input text box 
    const inputRef = useRef()
    const [imgUrl, setImage] = useState("")

    React.useImperativeHandle( ref, ()=> ({

        startChattingToRandomUser: ()=> {

            console.log(`inside focusOnMessageTextArea`);
            fetch('https://randomuser.me/api/')   
            .then(r=>r.json()) 
            .then(r=>  { 
                setImage(r.results[0].picture.large)
                inputRef.current.focus();
             } )
            
           
         }
     })
   )

    return (
        <div>            
             { imgUrl && 
                <>
                   <img src={imgUrl}/>
                   <div>
                        <textarea  rows="4" cols="50" type="text"  ref={inputRef} />
                   </div>
                  </>
             }
        </div>
    )
}
export default  React.forwardRef(LoadPerson)