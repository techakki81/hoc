# Ref Forwarding and useImperativeHandle

/* ref fwd is needed as ref is a keyword and you cant use anything else . if not 
      using ref fwd in child you will have to rename this ref to something else */

      // the trigger comes from parent button component 
    // make a call and loads the person ... 
    // message to the input text box 