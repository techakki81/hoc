import './App.css';
import LoadPerson from './component/LoadPerson';
import {useRef} from 'react'

function App() {
  const personRef = useRef(null)

 const setFocus = () =>{
   personRef.current.startChattingToRandomUser()
 }

  return (
    <div className="App">
      
      {/* ref fwd is needed as ref is a keyword and you cant use anything else . if not 
      using ref fwd in child you will have to rename this ref to something else */}

      <LoadPerson ref={personRef} />
      <button onClick={setFocus}>Load Random User</button>

    </div>
  );
}

export default App;

